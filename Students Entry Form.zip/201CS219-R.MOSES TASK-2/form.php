<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel = "stylesheet" 
         href = "https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" 
         integrity = "sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" 
         crossorigin = "anonymous">
    <link rel="stylesheet" href="/style.css">
         <script>
            function showUser() {
                var xmlhttp = new XMLHttpRequest();
                xmlhttp.onreadystatechange = function() {
                  if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("txt").innerHTML = this.responseText;
                  }
                };
                xmlhttp.open("GET","fetch.php",true);
                xmlhttp.send();
              }  
    </script>
        </head>
<body>
    <h1>Students Entry Form</h1>
    <div class="form">
        <br>
    <form action="student.php" method="get">
        Roll No: <input class="roll" type="text" name="Roll" placeholder="Roll No">
        Name: <input class="name" type="text" name="name" placeholder="Name"><br><br>
        Department: <input class="dept" type="text" name="dep" placeholder="Department"><br><br>
        <label for="Gender" >Gender:</label>
        <select class="gen" name="Gender" id="gender">
            <option value="--Select--">--Select--</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="none">Others</option>
        </select><br><br>
        Date Of Birth: <input class="dob" type="date" name="dob" placeholder="Date of Birth"><br><br>
        Address: <input class="add" type="textarea" name="add" placeholder="Address"><br><br>
        MobileNo: <input class="pno" type="text" name="pno" placeholder="Mobile No"><br><br>
        Email: <input type="email" name="email" id="mail" placeholder="Email"><br><br>
        <button type = "Submit" class = "btn btn-success">Insert</button>
        <button type="reset" class="btn btn-danger">Clear</button>
        <a href="fetch.php"> <input   type = "button" onclick="showUser()" class = "btn btn-dark" id="selectbtn" value="Select"></a>
    </form>
    </div>
</body>
</html>