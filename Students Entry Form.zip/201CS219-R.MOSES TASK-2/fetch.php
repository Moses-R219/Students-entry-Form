<html>
  <style>
    body
    {
      background-image: linear-gradient(70deg,#21d190,#9796F0);
    }
table,th,td,tr
{
  table-layout: fixed ;
  border:5px solid tomato;
  border-collapse:collapse;
  font-size:20px;
  margin-left:10% ;
  width:80%%;
  padding:20px;
  height:30%;
}
tr:nth-child(even) {
  background: lightgreen;
}
tr:nth-child(odd) {
  background: whitesmoke;
}
th
{
  background: wheat;
}
h1
{
  text-align:center;
  font-family:Algeria;
  margin-top: 10%;
  font-style: oblique;
  background: orange;
  margin-left: 300px;
  margin-right: 300px;
}
th:hover
{
background: lightblue;
}
h1:hover 
{
  background-color:#69FF97;
  color:#6A11CB;
  text-transform: uppercase;
  

}
  </style>
  <body>
    
<div class='details'>
<?php
$servername='localhost';
$username='root';
$password='';
$dbname='student';

$con=mysqli_connect($servername,$username,$password,$dbname);




$sql="SELECT * FROM studentdetails";
$result=mysqli_query($con,$sql);
echo" <h1>Students Details</h1> ";
echo "<table >
<tr>
<th>Roll No</th>
<th>Name</th>
<th>Dept</th>
<th>Gender</th>
<th class='g'>DOB</th>
<th>Address</th>
<th>Mobile No</th>
<th>Email</th>

</tr>";
while($row = mysqli_fetch_array($result)) {
  
  echo"<tr>";
        echo '<td>'.$row["Roll No"].'</td>';
       echo'<td>'.$row["Name"].'</td>';
        echo'<td>'.$row["Department"].' </td>';
        echo'<td>'.$row["Gender"].'</td>';
       echo '<td>'.$row["DOB"].' </td>';
       echo '<td>'.$row["Address"] .'</td>';
        echo'<td>'.$row["MobileNo"].'</td>';
       echo '<td>'.$row["Email"].'</td>';
  echo"</tr>";
  
}
echo "</table>";

mysqli_close($con);

?>
</div>
  </body>
</html>