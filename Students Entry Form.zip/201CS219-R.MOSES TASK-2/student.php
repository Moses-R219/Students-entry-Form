<html>
    <style>
        body
        {
            background: lightgreen;
        }
    </style>
    <body>
<?php
$servername='localhost';
$username='root';
$password='';
$dbname='student';

$rollno=$_GET['Roll'];
$name=$_GET['name'];
$Dept=$_GET['dep'];
$Gender=$_GET['Gender'];
$DOB=$_GET['dob'];
$Add=$_GET['add'];
$MobNo=$_GET['pno'];
$Email=$_GET['email'];
$conn=new mysqli($servername,$username,$password,$dbname);


$sql="insert into studentdetails values('$rollno','$name','$Dept','$Gender','$DOB','$Add','$MobNo','$Email')";
 
if($conn->query($sql)==true)
{
    echo "<h1 style='text-align:center;font-family:Algeria;color:Green;margin-top:25%;'>Inserted successfully</h1>";
}
else{
echo "Insert Correctly";
}
?>
 </body>
</html>